import { useState } from "react";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import { 
  Calendar, 
  Clock, 
  BarChart3, 
  ExternalLink, 
  Copy, 
  ChevronDown,
  MoreHorizontal,
  SlidersHorizontal,
  Bookmark,
  Video,
  Globe,
  Plus,
  Bold,
  Italic,
  Link as LinkIcon,
  ChevronRight,
  X,
  ArrowLeft,
  Settings,
  Users,
  Repeat,
  Webhook,
  Zap,
  User,
  HelpCircle,
  LogOut,
  Check,
  CreditCard,
  Code,
  Bell,
  Key,
  Trash2,
  Info,
  UserCircle2,
  CalendarDays,
  Lock,
  Palette,
  Shield,
  Briefcase
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "./components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "./components/ui/dialog";
import { Label } from "./components/ui/label";
import { Switch } from "./components/ui/switch";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "./components/ui/sheet";
import { Checkbox } from "./components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "./components/ui/avatar";
import { AuthScreensDemo } from "./components/auth-screens-demo";

export default function App() {
  const [currentView, setCurrentView] = useState("availability");
  const [profileSection, setProfileSection] = useState("profile");
  const [activeTab, setActiveTab] = useState("past");
  const [selectedBooking, setSelectedBooking] = useState<number | null>(null);
  const [isNewEventDialogOpen, setIsNewEventDialogOpen] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [newEventTitle, setNewEventTitle] = useState("");
  const [newEventUrl, setNewEventUrl] = useState("");
  const [newEventDescription, setNewEventDescription] = useState("");
  const [newEventDuration, setNewEventDuration] = useState("15");
  const [selectedEventSection, setSelectedEventSection] = useState("basics");
  
  // Edit Event State
  const [eventTitle, setEventTitle] = useState("test");
  const [eventDescription, setEventDescription] = useState("");
  const [eventUrl, setEventUrl] = useState("test");
  const [eventDuration, setEventDuration] = useState("15");
  const [eventEnabled, setEventEnabled] = useState(true);
  const [allowMultipleDurations, setAllowMultipleDurations] = useState(false);
  const [eventLocation, setEventLocation] = useState("Google Meet");
  
  // Limits State
  const [beforeEventBuffer, setBeforeEventBuffer] = useState("No buffer time");
  const [afterEventBuffer, setAfterEventBuffer] = useState("No buffer time");
  const [minimumNotice, setMinimumNotice] = useState("2");
  const [minimumNoticeUnit, setMinimumNoticeUnit] = useState("Hours");
  const [timeSlotIntervals, setTimeSlotIntervals] = useState("Use event length (default)");
  const [limitBookingFrequency, setLimitBookingFrequency] = useState(false);
  const [onlyFirstSlot, setOnlyFirstSlot] = useState(false);
  const [limitTotalDuration, setLimitTotalDuration] = useState(false);
  const [limitUpcomingBookings, setLimitUpcomingBookings] = useState(false);
  const [limitFutureBookings, setLimitFutureBookings] = useState(false);
  
  // Filter State
  const [filterEventTypes, setFilterEventTypes] = useState<string[]>([]);
  const [filterDateRange, setFilterDateRange] = useState("all");
  const [filterMeetingTypes, setFilterMeetingTypes] = useState<string[]>([]);
  const [filterDurations, setFilterDurations] = useState<string[]>([]);
  
  // Profile State
  const [profileUsername, setProfileUsername] = useState("concrete-kreative");
  const [profileFullName, setProfileFullName] = useState("Concrete Kreative");
  const [profileEmail, setProfileEmail] = useState("darrell@concretekreative.com");
  const [profileAbout, setProfileAbout] = useState("");
  
  // Calendar toggles state
  const [calendarToggles, setCalendarToggles] = useState({
    darrellCK: true,
    holidaysUS: false,
    transferredJan: false,
    transferredChirag1: false,
    transferredChirag2: false,
  });
  
  // General settings state
  const [generalLanguage, setGeneralLanguage] = useState("english");
  const [generalTimezone, setGeneralTimezone] = useState("america-new-york");
  const [generalTimeFormat, setGeneralTimeFormat] = useState("12");
  const [generalStartOfWeek, setGeneralStartOfWeek] = useState("sunday");
  const [dynamicGroupLinks, setDynamicGroupLinks] = useState(true);
  const [allowSearchEngineIndexing, setAllowSearchEngineIndexing] = useState(true);
  const [monthlyDigestEmail, setMonthlyDigestEmail] = useState(true);
  const [preventImpersonation, setPreventImpersonation] = useState(false);

  // Availability State
  const [selectedAvailability, setSelectedAvailability] = useState("Working Hours");
  const [isEditingAvailability, setIsEditingAvailability] = useState(false);
  const [availabilityName, setAvailabilityName] = useState("");
  const [availabilityTimezone, setAvailabilityTimezone] = useState("america-new-york");
  const weeklySchedule = [
    { day: "Sunday", available: false, start: "", end: "" },
    { day: "Monday", available: true, start: "12:00 PM", end: "4:00 PM" },
    { day: "Tuesday", available: true, start: "12:00 PM", end: "4:00 PM" },
    { day: "Wednesday", available: true, start: "12:00 PM", end: "4:00 PM" },
    { day: "Thursday", available: true, start: "12:00 PM", end: "4:00 PM" },
    { day: "Friday", available: true, start: "12:00 PM", end: "4:00 PM" },
    { day: "Saturday", available: false, start: "", end: "" },
  ];

  const tabs = [
    { id: "upcoming", label: "Upcoming" },
    { id: "unconfirmed", label: "Unconfirmed" },
    { id: "recurring", label: "Recurring" },
    { id: "past", label: "Past" },
    { id: "cancelled", label: "Cancelled" },
  ];

  const bookings = [
    {
      id: 1,
      date: "28 Oct 2025",
      time: "10:00am - 10:30am",
      title: "30 Minute Meeting",
      attendees: "You and Sarah Chen",
      hasGoogleMeet: true,
      fullDate: "Tuesday, October 28, 2025",
      fullTime: "10:00 AM - 10:30 AM (Pacific Daylight Time)",
      host: {
        name: "You",
        email: "you@example.com"
      },
      guest: {
        name: "Sarah Chen",
        email: "sarah.chen@techcorp.com"
      }
    },
    {
      id: 2,
      date: "29 Oct 2025",
      time: "2:00pm - 3:00pm",
      title: "Discovery Call",
      attendees: "You and Michael Rodriguez",
      hasGoogleMeet: true,
      fullDate: "Wednesday, October 29, 2025",
      fullTime: "2:00 PM - 3:00 PM (Pacific Daylight Time)",
      host: {
        name: "You",
        email: "you@example.com"
      },
      guest: {
        name: "Michael Rodriguez",
        email: "m.rodriguez@startup.io"
      }
    },
    {
      id: 3,
      date: "30 Oct 2025",
      time: "11:30am - 12:00pm",
      title: "Quick Sync",
      attendees: "You and Emma Watson",
      hasGoogleMeet: false,
      fullDate: "Thursday, October 30, 2025",
      fullTime: "11:30 AM - 12:00 PM (Pacific Daylight Time)",
      host: {
        name: "You",
        email: "you@example.com"
      },
      guest: {
        name: "Emma Watson",
        email: "emma.w@designco.com"
      }
    },
    {
      id: 4,
      date: "31 Oct 2025",
      time: "3:30pm - 4:30pm",
      title: "Strategy Session",
      attendees: "You and James Park",
      hasGoogleMeet: true,
      fullDate: "Friday, October 31, 2025",
      fullTime: "3:30 PM - 4:30 PM (Pacific Daylight Time)",
      host: {
        name: "You",
        email: "you@example.com"
      },
      guest: {
        name: "James Park",
        email: "jpark@consulting.com"
      }
    }
  ];

  if (selectedBooking !== null) {
    const booking = bookings.find(b => b.id === selectedBooking);
    if (!booking) return null;

    return (
      <div className="min-h-screen bg-gray-100">
        <div className="p-6">
          <button 
            onClick={() => setSelectedBooking(null)}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
          >
            <ChevronDown className="h-4 w-4 rotate-90" />
            Back to bookings
          </button>
        </div>

        <div className="flex justify-center px-6 pb-6">
          <div className="bg-white rounded-lg shadow-sm p-8 max-w-2xl w-full">
            {/* Success Icon */}
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>

            {/* Header */}
            <div className="text-center mb-8">
              <h2 className="text-gray-900 mb-2">The event is in the past</h2>
              <p className="text-gray-600">
                We sent an email with a calendar invitation with the details to everyone.
              </p>
            </div>

            {/* Details */}
            <div className="space-y-6 mb-8">
              {/* What */}
              <div className="flex gap-8">
                <div className="w-20 text-gray-700">What</div>
                <div className="flex-1 text-gray-900">{booking.title}</div>
              </div>

              {/* When */}
              <div className="flex gap-8">
                <div className="w-20 text-gray-700">When</div>
                <div className="flex-1">
                  <div className="text-gray-900">{booking.fullDate}</div>
                  <div className="text-gray-900">{booking.fullTime}</div>
                </div>
              </div>

              {/* Who */}
              <div className="flex gap-8">
                <div className="w-20 text-gray-700">Who</div>
                <div className="flex-1">
                  <div className="mb-2">
                    <span className="text-gray-900">{booking.host.name}</span>
                    <span className="ml-2 text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">Host</span>
                  </div>
                  <div className="text-gray-600 mb-3">{booking.host.email}</div>
                  <div className="text-gray-900 mb-1">{booking.guest.name}</div>
                  <div className="text-gray-600">{booking.guest.email}</div>
                </div>
              </div>

              {/* Where */}
              <div className="flex gap-8">
                <div className="w-20 text-gray-700">Where</div>
                <div className="flex-1">
                  <a href="#" className="text-gray-900 hover:text-gray-700 inline-flex items-center gap-1">
                    Google Meet
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </div>
            </div>

            {/* Need to make a change */}
            <div className="text-center mb-8">
              <p className="text-gray-700">Need to make a change?</p>
            </div>

            {/* Add to calendar */}
            <div className="flex items-center justify-center gap-4">
              <span className="text-gray-700">Add to calendar</span>
              <div className="flex gap-2">
                <button className="p-2 border border-gray-200 rounded hover:bg-gray-50" title="Google Calendar">
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M5 3h14c1.1 0 2 .9 2 2v14c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2z"/>
                    <path fill="#fff" d="M16 9h-3V6h-2v3H8v2h3v3h2v-3h3V9z"/>
                  </svg>
                </button>
                <button className="p-2 border border-gray-200 rounded hover:bg-gray-50" title="Office 365">
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#D83B01" d="M20 3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/>
                    <path fill="#fff" d="M12 6L6 9v6l6 3 6-3V9l-6-3zm0 2.2L15.5 10 12 11.8 8.5 10 12 8.2z"/>
                  </svg>
                </button>
                <button className="p-2 border border-gray-200 rounded hover:bg-gray-50" title="Apple Calendar">
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#000" d="M5 3h14c1.1 0 2 .9 2 2v14c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2z"/>
                    <rect fill="#fff" x="6" y="9" width="12" height="2"/>
                    <rect fill="#fff" x="6" y="13" width="8" height="2"/>
                  </svg>
                </button>
                <button className="p-2 border border-gray-200 rounded hover:bg-gray-50" title="Outlook">
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#0078D4" d="M5 3h14c1.1 0 2 .9 2 2v14c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2z"/>
                    <path fill="#fff" d="M12 8c-2.2 0-4 1.8-4 4s1.8 4 4 4 4-1.8 4-4-1.8-4-4-4zm0 6c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Profile Takeover View
  if (currentView === "myProfile") {
    return (
      <div className="flex h-screen bg-gray-50">
        {/* Profile Layout with Left Sidebar */}
        <div className="w-56 border-r border-gray-200 bg-white">
          {/* Back Button */}
          <div className="p-4 border-b border-gray-200">
            <button
              onClick={() => setCurrentView("event-types")}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </button>
          </div>

          <div className="p-4 flex-1 overflow-y-auto">
            <div className="mb-4">
              <span className="text-gray-900 text-sm">Concrete Kreative</span>
            </div>
            
            <div className="space-y-1">
              <button
                onClick={() => setProfileSection("profile")}
                className={`w-full text-left px-3 py-2 rounded text-sm ${
                  profileSection === "profile"
                    ? "bg-gray-100 text-gray-900"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                Profile
              </button>
              <button
                onClick={() => setProfileSection("general")}
                className={`w-full text-left px-3 py-2 rounded text-sm ${
                  profileSection === "general"
                    ? "bg-gray-100 text-gray-900"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                General
              </button>
              <button
                onClick={() => setProfileSection("calendars")}
                className={`w-full text-left px-3 py-2 rounded text-sm ${
                  profileSection === "calendars"
                    ? "bg-gray-100 text-gray-900"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                Calendars
              </button>
              <button
                onClick={() => setProfileSection("conferencing")}
                className={`w-full text-left px-3 py-2 rounded text-sm ${
                  profileSection === "conferencing"
                    ? "bg-gray-100 text-gray-900"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                Conferencing
              </button>
              
              {/* Security Section */}
              <div className="pt-2">
                <button className="w-full text-left px-3 py-2 text-gray-600 hover:bg-gray-50 rounded text-sm flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  <span>Security</span>
                </button>
                <div className="ml-4 space-y-1 mt-1">
                  <button
                    onClick={() => setProfileSection("password")}
                    className={`w-full text-left px-3 py-2 rounded text-sm ${
                      profileSection === "password"
                        ? "bg-gray-100 text-gray-900"
                        : "text-gray-600 hover:bg-gray-50"
                    }`}
                  >
                    Password
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Profile Content */}
        <div className="flex-1 flex flex-col overflow-hidden bg-gray-50">
          {profileSection === "profile" && (
            <>
              {/* Header */}
              <div className="bg-white border-b border-gray-200 px-8 py-6">
                <h1 className="text-gray-900 mb-1">Profile</h1>
                <p className="text-gray-600">
                  Manage settings for your public profile.
                </p>
              </div>

              {/* Form Content */}
              <div className="flex-1 overflow-y-auto px-8 py-6">
                <div className="max-w-3xl space-y-8">
                  {/* Avatar Section */}
                  <div className="bg-white rounded-lg border border-gray-200 p-6">
                    <div className="flex items-start gap-6">
                      <Avatar className="w-20 h-20">
                        <AvatarFallback className="bg-gray-400 text-white text-xl">
                          CK
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <Label className="text-gray-900 mb-2 block">Profile Picture</Label>
                        <p className="text-gray-600 text-sm mb-4">
                          Upload a new avatar. Recommended size is 256x256px.
                        </p>
                        <div className="flex gap-3">
                          <Button variant="outline" size="sm">Upload</Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                            Remove
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Basic Information */}
                  <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-6">
                    <div>
                      <h3 className="text-gray-900 mb-4">Basic Information</h3>
                    </div>

                    {/* Username */}
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-500 text-sm">yourcompany.com/</span>
                        <Input
                          id="username"
                          value={profileUsername}
                          onChange={(e) => setProfileUsername(e.target.value)}
                          className="flex-1"
                        />
                      </div>
                      <p className="text-gray-500 text-sm">
                        This is your personal URL namespace within our scheduling system.
                      </p>
                    </div>

                    {/* Full Name */}
                    <div className="space-y-2">
                      <Label htmlFor="fullname">Full Name</Label>
                      <Input
                        id="fullname"
                        value={profileFullName}
                        onChange={(e) => setProfileFullName(e.target.value)}
                      />
                    </div>

                    {/* Email */}
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={profileEmail}
                        onChange={(e) => setProfileEmail(e.target.value)}
                      />
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        <span className="text-green-600">Verified</span>
                      </div>
                    </div>

                    {/* About/Bio */}
                    <div className="space-y-2">
                      <Label htmlFor="about">About</Label>
                      <Textarea
                        id="about"
                        placeholder="A little something about you"
                        value={profileAbout}
                        onChange={(e) => setProfileAbout(e.target.value)}
                        rows={4}
                      />
                      <p className="text-gray-500 text-sm">
                        Brief description for your profile. URLs are hyperlinked.
                      </p>
                    </div>
                  </div>

                  {/* Timezone */}
                  <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-4">
                    <div>
                      <h3 className="text-gray-900 mb-1">Timezone</h3>
                      <p className="text-gray-600 text-sm">
                        Your current timezone used for scheduling
                      </p>
                    </div>
                    <div className="space-y-2">
                      <Select defaultValue="america-new-york">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="america-new-york">
                            (GMT-05:00) America/New York
                          </SelectItem>
                          <SelectItem value="america-los-angeles">
                            (GMT-08:00) America/Los Angeles
                          </SelectItem>
                          <SelectItem value="america-chicago">
                            (GMT-06:00) America/Chicago
                          </SelectItem>
                          <SelectItem value="europe-london">
                            (GMT+00:00) Europe/London
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Danger Zone */}
                  <div className="bg-white rounded-lg border border-red-200 p-6 space-y-4">
                    <div>
                      <h3 className="text-red-600 mb-1">Danger Zone</h3>
                      <p className="text-gray-600 text-sm">
                        Permanently delete your account and all associated data
                      </p>
                    </div>
                    <Button variant="outline" className="text-red-600 border-red-300 hover:bg-red-50 hover:text-red-700">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Account
                    </Button>
                  </div>

                  {/* Save Button */}
                  <div className="flex justify-end gap-3 pb-6">
                    <Button variant="outline">Cancel</Button>
                    <Button>Save Changes</Button>
                  </div>
                </div>
              </div>
            </>
          )}

          {profileSection === "calendars" && (
            <>
              {/* Header */}
              <div className="bg-white border-b border-gray-200 px-8 py-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h1 className="text-gray-900 mb-1">Calendars</h1>
                    <p className="text-gray-600">
                      Configure how your event types interact with your calendars
                    </p>
                  </div>
                  <Button variant="outline" className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add Calendar
                  </Button>
                </div>
              </div>

              {/* Calendars Content */}
              <div className="flex-1 overflow-y-auto px-8 py-6">
                <div className="max-w-3xl space-y-6">
                  {/* Add to calendar section */}
                  <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-4">
                    <div>
                      <h3 className="text-gray-900 mb-1">Add to calendar</h3>
                      <p className="text-gray-600 text-sm">
                        Select where to add events when you're booked.
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="add-events-to">Add events to</Label>
                      <Select defaultValue="darrell-google">
                        <SelectTrigger id="add-events-to">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="darrell-google">
                            Darrell (CK) (Google - Darrell (CK))
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-gray-500 text-sm">
                        You can override this on a per-event basis in Advanced settings in each event type.
                      </p>
                    </div>
                  </div>

                  {/* Check for conflicts section */}
                  <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-gray-900 mb-1">Check for conflicts</h3>
                        <p className="text-gray-600 text-sm">
                          Select which calendars you want to check for conflicts to prevent double bookings.
                        </p>
                      </div>
                      <Button variant="outline" size="sm" className="gap-2">
                        <Plus className="h-4 w-4" />
                        Add
                      </Button>
                    </div>

                    {/* Google Calendar Card */}
                    <div className="border border-gray-200 rounded-lg p-4 space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          {/* Google Calendar Icon */}
                          <div className="flex-shrink-0">
                            <svg className="w-10 h-10" viewBox="0 0 48 48" fill="none">
                              <rect width="48" height="48" rx="8" fill="#4285F4"/>
                              <path d="M24 10v14h14" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                              <circle cx="24" cy="24" r="10" stroke="white" strokeWidth="2" fill="none"/>
                              <text x="24" y="18" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">31</text>
                            </svg>
                          </div>
                          <div>
                            <h4 className="text-gray-900">Google Calendar</h4>
                            <p className="text-gray-600 text-sm">darrell@concretekreative.com</p>
                          </div>
                        </div>
                        <button className="p-2 hover:bg-gray-100 rounded">
                          <MoreHorizontal className="h-4 w-4 text-gray-600" />
                        </button>
                      </div>

                      {/* Calendar toggles */}
                      <div className="space-y-3">
                        <p className="text-gray-600 text-sm">
                          Toggle the calendars you want to check for conflicts to prevent double bookings.
                        </p>

                        {/* Darrell (CK) */}
                        <div className="flex items-center justify-between py-2">
                          <span className="text-gray-900">Darrell (CK)</span>
                          <Switch
                            checked={calendarToggles.darrellCK}
                            onCheckedChange={(checked) =>
                              setCalendarToggles({ ...calendarToggles, darrellCK: checked })
                            }
                          />
                        </div>

                        {/* Holidays in United States */}
                        <div className="flex items-center justify-between py-2">
                          <span className="text-gray-900">Holidays in United States</span>
                          <Switch
                            checked={calendarToggles.holidaysUS}
                            onCheckedChange={(checked) =>
                              setCalendarToggles({ ...calendarToggles, holidaysUS: checked })
                            }
                          />
                        </div>

                        {/* Transferred from janpatrick */}
                        <div className="flex items-center justify-between py-2">
                          <span className="text-gray-900">Transferred from janpatrick@concretekreative.com</span>
                          <Switch
                            checked={calendarToggles.transferredJan}
                            onCheckedChange={(checked) =>
                              setCalendarToggles({ ...calendarToggles, transferredJan: checked })
                            }
                          />
                        </div>

                        {/* Transferred from chirag.patel 1 */}
                        <div className="flex items-center justify-between py-2">
                          <span className="text-gray-900">Transferred from chirag.patel@concretekreative.com</span>
                          <Switch
                            checked={calendarToggles.transferredChirag1}
                            onCheckedChange={(checked) =>
                              setCalendarToggles({ ...calendarToggles, transferredChirag1: checked })
                            }
                          />
                        </div>

                        {/* Transferred from chirag.patel 2 */}
                        <div className="flex items-center justify-between py-2">
                          <span className="text-gray-900">Transferred from chirag.patel@concretekreative.com</span>
                          <Switch
                            checked={calendarToggles.transferredChirag2}
                            onCheckedChange={(checked) =>
                              setCalendarToggles({ ...calendarToggles, transferredChirag2: checked })
                            }
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {profileSection === "general" && (
            <>
              {/* Header */}
              <div className="bg-white border-b border-gray-200 px-8 py-6">
                <h1 className="text-gray-900 mb-1">General</h1>
                <p className="text-gray-600">
                  Manage settings for your language and timezone
                </p>
              </div>

              {/* General Content */}
              <div className="flex-1 overflow-y-auto px-8 py-6">
                <div className="max-w-3xl space-y-6">
                  {/* Language & Timezone Settings */}
                  <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-6">
                    {/* Language */}
                    <div className="space-y-2">
                      <Label htmlFor="language">Language</Label>
                      <Select value={generalLanguage} onValueChange={setGeneralLanguage}>
                        <SelectTrigger id="language">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="english">English</SelectItem>
                          <SelectItem value="spanish">Spanish</SelectItem>
                          <SelectItem value="french">French</SelectItem>
                          <SelectItem value="german">German</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Timezone */}
                    <div className="space-y-2">
                      <Label htmlFor="timezone">Timezone</Label>
                      <Select value={generalTimezone} onValueChange={setGeneralTimezone}>
                        <SelectTrigger id="timezone">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="america-new-york">America/New York</SelectItem>
                          <SelectItem value="america-los-angeles">America/Los Angeles</SelectItem>
                          <SelectItem value="america-chicago">America/Chicago</SelectItem>
                          <SelectItem value="europe-london">Europe/London</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button variant="outline" size="sm" className="gap-2 mt-2">
                        <CalendarDays className="h-4 w-4" />
                        Schedule timezone change
                      </Button>
                    </div>

                    {/* Time format */}
                    <div className="space-y-2">
                      <Label htmlFor="time-format">Time format</Label>
                      <Select value={generalTimeFormat} onValueChange={setGeneralTimeFormat}>
                        <SelectTrigger id="time-format">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="12">12 hour</SelectItem>
                          <SelectItem value="24">24 hour</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-gray-500 text-sm">
                        This is an internal setting and will not affect how times are displayed on public booking pages for you or anyone booking you.
                      </p>
                    </div>

                    {/* Start of week */}
                    <div className="space-y-2">
                      <Label htmlFor="start-of-week">Start of week</Label>
                      <Select value={generalStartOfWeek} onValueChange={setGeneralStartOfWeek}>
                        <SelectTrigger id="start-of-week">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sunday">Sunday</SelectItem>
                          <SelectItem value="monday">Monday</SelectItem>
                          <SelectItem value="saturday">Saturday</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Update Button */}
                    <div className="flex justify-end pt-2">
                      <Button>Update</Button>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {profileSection === "conferencing" && (
            <>
              {/* Header */}
              <div className="bg-white border-b border-gray-200 px-8 py-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h1 className="text-gray-900 mb-1">Conferencing</h1>
                    <p className="text-gray-600">
                      Add your favourite video conferencing apps for your meetings
                    </p>
                  </div>
                  <Button variant="outline" className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add
                  </Button>
                </div>
              </div>

              {/* Conferencing Content */}
              <div className="flex-1 overflow-y-auto px-8 py-6">
                <div className="max-w-3xl space-y-4">
                  {/* Google Meet */}
                  <div className="bg-white rounded-lg border border-gray-200 p-6">
                    <div className="flex items-start gap-4">
                      {/* Google Meet Icon */}
                      <div className="flex-shrink-0">
                        <svg className="w-12 h-12" viewBox="0 0 48 48" fill="none">
                          <rect width="48" height="48" rx="8" fill="#00832D"/>
                          <path d="M24 14L14 20V28L24 34L34 28V20L24 14Z" fill="#0066DA"/>
                          <path d="M24 14L34 20V28L24 34V14Z" fill="#E94235"/>
                          <path d="M14 20L24 26L34 20L24 14L14 20Z" fill="#2684FC"/>
                          <path d="M24 26V34L34 28V20L24 26Z" fill="#00AC47"/>
                          <circle cx="24" cy="24" r="6" fill="white"/>
                          <path d="M24 21V27M21 24H27" stroke="#00832D" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      </div>
                      
                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <h3 className="text-gray-900">Google Meet</h3>
                            <span className="px-2 py-0.5 bg-gray-100 text-gray-700 text-xs rounded">
                              Default
                            </span>
                          </div>
                          <button className="p-1 hover:bg-gray-100 rounded">
                            <MoreHorizontal className="h-4 w-4 text-gray-600" />
                          </button>
                        </div>
                        <p className="text-gray-600 text-sm">
                          Google Meet is Google's web-based video conferencing platform, designed to compete with major conferencing platforms.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {profileSection === "password" && (
            <>
              {/* Header */}
              <div className="bg-white border-b border-gray-200 px-8 py-6">
                <h1 className="text-gray-900 mb-1">Password</h1>
                <p className="text-gray-600">
                  Manage settings for your account passwords
                </p>
              </div>

              {/* Password Content */}
              <div className="flex-1 overflow-y-auto px-8 py-6">
                <div className="max-w-3xl">
                  <div className="bg-white rounded-lg border border-gray-200 p-6">
                    <h3 className="text-gray-900 mb-2">Your account is managed by GOOGLE</h3>
                    <p className="text-gray-600 text-sm mb-6">
                      To change your email, password, enable two-factor authentication and more, please visit your GOOGLE account settings.
                    </p>
                    <Button className="bg-gray-900 hover:bg-gray-800 text-white">
                      Create account password
                    </Button>
                  </div>
                </div>
              </div>
            </>
          )}

          {profileSection !== "profile" && profileSection !== "calendars" && profileSection !== "general" && profileSection !== "conferencing" && profileSection !== "password" && (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <Info className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-gray-900 mb-2">Section Not Implemented</h3>
                <p className="text-gray-600">
                  The {profileSection} section is not yet implemented.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-white">
      {/* Sidebar */}
      <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col">
        {/* User Profile */}
        <div className="p-4 border-b border-gray-200">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 w-full hover:bg-gray-100 rounded p-2">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-gray-400 text-white text-xs">
                    CK
                  </AvatarFallback>
                </Avatar>
                <span className="text-gray-900 flex-1 text-left">Concrete Kr...</span>
                <ChevronDown className="h-4 w-4 text-gray-600" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuItem onClick={() => setCurrentView("myProfile")}>
                <User className="h-4 w-4" />
                <span>My profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="h-4 w-4" />
                <span>My settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <LogOut className="h-4 w-4" />
                <span>Sign out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 overflow-y-auto">
          <div className="space-y-1">
            <button 
              onClick={() => setCurrentView("event-types")}
              className={`flex items-center gap-3 w-full px-3 py-2 rounded ${
                currentView === "event-types" 
                  ? "text-gray-900 bg-gray-200 hover:bg-gray-200" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Calendar className="h-4 w-4" />
              <span>Event Types</span>
            </button>
            <button 
              onClick={() => setCurrentView("bookings")}
              className={`flex items-center gap-3 w-full px-3 py-2 rounded ${
                currentView === "bookings" 
                  ? "text-gray-900 bg-gray-200 hover:bg-gray-200" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Calendar className="h-4 w-4" />
              <span>Bookings</span>
            </button>
            <button 
              onClick={() => setCurrentView("availability")}
              className={`flex items-center gap-3 w-full px-3 py-2 rounded ${
                currentView === "availability" 
                  ? "text-gray-900 bg-gray-200 hover:bg-gray-200" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Clock className="h-4 w-4" />
              <span>Availability</span>
            </button>
          </div>
        </nav>

        {/* Bottom Links */}
        <div className="p-3 border-t border-gray-200 space-y-1">
          <button className="flex items-center gap-3 w-full px-3 py-2 text-gray-600 hover:bg-gray-100 rounded">
            <ExternalLink className="h-4 w-4" />
            <span>View public page</span>
          </button>
          <button className="flex items-center gap-3 w-full px-3 py-2 text-gray-600 hover:bg-gray-100 rounded">
            <Copy className="h-4 w-4" />
            <span>Copy public page link</span>
          </button>
          <button 
            onClick={() => setCurrentView("auth-screens")}
            className={`flex items-center gap-3 w-full px-3 py-2 rounded ${
              currentView === "auth-screens" 
                ? "text-gray-900 bg-gray-200 hover:bg-gray-200" 
                : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <Lock className="h-4 w-4" />
            <span>Auth Screens</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {currentView === "event-types" ? (
          <>
            {/* Event Types Header */}
            <div className="border-b border-gray-200 p-6 flex items-start justify-between">
              <div>
                <h1 className="text-gray-900 mb-1">Event Types</h1>
                <p className="text-gray-600">
                  Create events to share for people to book on your calendar.
                </p>
              </div>
              <Button className="gap-2" onClick={() => setIsNewEventDialogOpen(true)}>
                <Plus className="h-4 w-4" />
                New
              </Button>
            </div>

            {/* Event Types Content */}
            <div className="flex-1 p-6 overflow-y-auto">
              {/* Event Type Card */}
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-gray-900 mb-1">30 Minute Meeting</h3>
                    <p className="text-gray-600 mb-2">30 min</p>
                    <a href="#" className="text-gray-600 hover:text-gray-900 text-sm">
                      View booking page
                    </a>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="p-2 hover:bg-gray-100 rounded">
                        <MoreHorizontal className="h-4 w-4 text-gray-600" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => setCurrentView("edit-event")}>Edit</DropdownMenuItem>
                      <DropdownMenuItem>Preview</DropdownMenuItem>
                      <DropdownMenuItem>Copy link</DropdownMenuItem>
                      <DropdownMenuItem>Duplicate</DropdownMenuItem>
                      <DropdownMenuItem>Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>
          </>
        ) : currentView === "edit-event" ? (
          <>
            {/* Edit Event Layout */}
            <div className="flex flex-1 overflow-hidden">
              {/* Middle Sidebar - Event Sections */}
              <div className="w-64 border-r border-gray-200 flex flex-col bg-white">
                {/* Back to Event Types */}
                <div className="p-4 border-b border-gray-200">
                  <button 
                    onClick={() => setCurrentView("event-types")}
                    className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>{eventTitle}</span>
                  </button>
                </div>

                {/* Sections List */}
                <div className="flex-1 overflow-y-auto p-2">
                  <button
                    onClick={() => setSelectedEventSection("basics")}
                    className={`w-full flex items-center justify-between p-3 rounded hover:bg-gray-100 ${
                      selectedEventSection === "basics" ? "bg-gray-100" : ""
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Clock className="h-4 w-4 text-gray-600" />
                      <div className="text-left">
                        <div className="text-gray-900">Basics</div>
                        <div className="text-gray-500 text-sm">{eventDuration} mins</div>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-gray-400" />
                  </button>

                  <button
                    onClick={() => setSelectedEventSection("availability")}
                    className={`w-full flex items-center justify-between p-3 rounded hover:bg-gray-100 ${
                      selectedEventSection === "availability" ? "bg-gray-100" : ""
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Calendar className="h-4 w-4 text-gray-600" />
                      <div className="text-left">
                        <div className="text-gray-900">Availability</div>
                        <div className="text-gray-500 text-sm">Working Hours</div>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-gray-400" />
                  </button>

                  <button
                    onClick={() => setSelectedEventSection("limits")}
                    className={`w-full flex items-center justify-between p-3 rounded hover:bg-gray-100 ${
                      selectedEventSection === "limits" ? "bg-gray-100" : ""
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <SlidersHorizontal className="h-4 w-4 text-gray-600" />
                      <div className="text-left">
                        <div className="text-gray-900">Limits</div>
                        <div className="text-gray-500 text-sm">How often you can be booked</div>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-gray-400" />
                  </button>
                </div>
              </div>

              {/* Main Content Area */}
              <div className="flex-1 flex flex-col overflow-hidden bg-gray-50">
                {/* Header */}
                <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                  <h2 className="text-gray-900">{eventTitle}</h2>
                  <div className="flex items-center gap-3">
                    <Switch checked={eventEnabled} onCheckedChange={setEventEnabled} />
                    <button className="p-2 hover:bg-gray-100 rounded">
                      <ExternalLink className="h-4 w-4 text-gray-600" />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded">
                      <Copy className="h-4 w-4 text-gray-600" />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded">
                      <Bookmark className="h-4 w-4 text-gray-600" />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded">
                      <MoreHorizontal className="h-4 w-4 text-gray-600" />
                    </button>
                    <Button>Save</Button>
                  </div>
                </div>

                {/* Form Content */}
                <div className="flex-1 overflow-y-auto p-6">
                  <div className="max-w-2xl space-y-6">
                    {selectedEventSection === "basics" ? (
                      <>
                        {/* Title */}
                        <div className="space-y-2">
                          <Label htmlFor="event-title">Title</Label>
                          <Input
                            id="event-title"
                            value={eventTitle}
                            onChange={(e) => setEventTitle(e.target.value)}
                          />
                        </div>

                        {/* Description */}
                        <div className="space-y-2">
                          <Label htmlFor="event-description">Description</Label>
                          <div className="border border-gray-200 rounded-md bg-white">
                            <div className="flex items-center gap-1 p-2 border-b border-gray-200">
                              <button className="p-1 hover:bg-gray-100 rounded">
                                <Bold className="h-4 w-4 text-gray-600" />
                              </button>
                              <button className="p-1 hover:bg-gray-100 rounded">
                                <Italic className="h-4 w-4 text-gray-600" />
                              </button>
                              <button className="p-1 hover:bg-gray-100 rounded">
                                <LinkIcon className="h-4 w-4 text-gray-600" />
                              </button>
                            </div>
                            <Textarea
                              id="event-description"
                              placeholder="A quick video meeting."
                              value={eventDescription}
                              onChange={(e) => setEventDescription(e.target.value)}
                              className="border-0 focus-visible:ring-0 resize-none"
                              rows={3}
                            />
                          </div>
                        </div>

                        {/* URL */}
                        <div className="space-y-2">
                          <Label htmlFor="event-url">URL</Label>
                          <div className="flex items-center gap-2">
                            <span className="text-gray-500">yourdomain.com/username/</span>
                            <Input
                              id="event-url"
                              value={eventUrl}
                              onChange={(e) => setEventUrl(e.target.value)}
                              className="flex-1"
                            />
                          </div>
                        </div>

                        {/* Duration */}
                        <div className="space-y-3">
                          <Label htmlFor="event-duration">Duration</Label>
                          <div className="flex items-center gap-2">
                            <Input
                              id="event-duration"
                              type="number"
                              value={eventDuration}
                              onChange={(e) => setEventDuration(e.target.value)}
                              className="w-24"
                            />
                            <span className="text-gray-600">Minutes</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={allowMultipleDurations}
                              onCheckedChange={setAllowMultipleDurations}
                            />
                            <Label htmlFor="multiple-durations" className="cursor-pointer">
                              Allow multiple durations
                            </Label>
                          </div>
                        </div>

                        {/* Location */}
                        <div className="space-y-3">
                          <Label>Location</Label>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 p-3 bg-white border border-gray-200 rounded-md">
                              <Video className="h-4 w-4 text-gray-600" />
                              <span className="flex-1 text-gray-900">{eventLocation}</span>
                              <button className="p-1 hover:bg-gray-100 rounded">
                                <X className="h-4 w-4 text-gray-600" />
                              </button>
                            </div>
                            <Button variant="outline" className="w-full gap-2">
                              <Plus className="h-4 w-4" />
                              Add a location
                            </Button>
                            <p className="text-gray-500 text-sm">
                              Can't find the right conferencing app?{" "}
                              <a href="#" className="text-blue-600 hover:underline">
                                Visit our App Store.
                              </a>
                            </p>
                          </div>
                        </div>
                      </>
                    ) : selectedEventSection === "limits" ? (
                      <>
                        {/* Before/After Event Buffer */}
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="before-buffer">Before event</Label>
                            <Select value={beforeEventBuffer} onValueChange={setBeforeEventBuffer}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="No buffer time">No buffer time</SelectItem>
                                <SelectItem value="5 minutes">5 minutes</SelectItem>
                                <SelectItem value="10 minutes">10 minutes</SelectItem>
                                <SelectItem value="15 minutes">15 minutes</SelectItem>
                                <SelectItem value="30 minutes">30 minutes</SelectItem>
                                <SelectItem value="45 minutes">45 minutes</SelectItem>
                                <SelectItem value="1 hour">1 hour</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="after-buffer">After event</Label>
                            <Select value={afterEventBuffer} onValueChange={setAfterEventBuffer}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="No buffer time">No buffer time</SelectItem>
                                <SelectItem value="5 minutes">5 minutes</SelectItem>
                                <SelectItem value="10 minutes">10 minutes</SelectItem>
                                <SelectItem value="15 minutes">15 minutes</SelectItem>
                                <SelectItem value="30 minutes">30 minutes</SelectItem>
                                <SelectItem value="45 minutes">45 minutes</SelectItem>
                                <SelectItem value="1 hour">1 hour</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* Minimum Notice / Time-slot intervals */}
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="minimum-notice">Minimum Notice</Label>
                            <div className="flex items-center gap-2">
                              <Input
                                id="minimum-notice"
                                type="number"
                                value={minimumNotice}
                                onChange={(e) => setMinimumNotice(e.target.value)}
                                className="w-20"
                              />
                              <Select value={minimumNoticeUnit} onValueChange={setMinimumNoticeUnit}>
                                <SelectTrigger className="flex-1">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Minutes">Minutes</SelectItem>
                                  <SelectItem value="Hours">Hours</SelectItem>
                                  <SelectItem value="Days">Days</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="time-slot-intervals">Time-slot intervals</Label>
                            <Select value={timeSlotIntervals} onValueChange={setTimeSlotIntervals}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Use event length (default)">Use event length (default)</SelectItem>
                                <SelectItem value="15 minutes">15 minutes</SelectItem>
                                <SelectItem value="30 minutes">30 minutes</SelectItem>
                                <SelectItem value="60 minutes">60 minutes</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* Limit booking frequency */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg">
                            <div className="flex-1">
                              <div className="text-gray-900 mb-1">Limit booking frequency</div>
                              <div className="text-gray-500 text-sm">Limit how many times this event can be booked</div>
                            </div>
                            <Switch
                              checked={limitBookingFrequency}
                              onCheckedChange={setLimitBookingFrequency}
                            />
                          </div>
                        </div>

                        {/* Only show first slot */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg">
                            <div className="flex-1">
                              <div className="text-gray-900 mb-1">Only show the first slot of each day as available</div>
                              <div className="text-gray-500 text-sm">This will limit your availability for this event type to one slot per day, scheduled at the earliest available time.</div>
                            </div>
                            <Switch
                              checked={onlyFirstSlot}
                              onCheckedChange={setOnlyFirstSlot}
                            />
                          </div>
                        </div>

                        {/* Limit total booking duration */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg">
                            <div className="flex-1">
                              <div className="text-gray-900 mb-1">Limit total booking duration</div>
                              <div className="text-gray-500 text-sm">Limit total amount of time that this event can be booked</div>
                            </div>
                            <Switch
                              checked={limitTotalDuration}
                              onCheckedChange={setLimitTotalDuration}
                            />
                          </div>
                        </div>

                        {/* Limit number of upcoming bookings */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg">
                            <div className="flex-1">
                              <div className="text-gray-900 mb-1">Limit number of upcoming bookings per booker</div>
                              <div className="text-gray-500 text-sm">Limit the number of active bookings a booker can make for this event type</div>
                            </div>
                            <Switch
                              checked={limitUpcomingBookings}
                              onCheckedChange={setLimitUpcomingBookings}
                            />
                          </div>
                        </div>

                        {/* Limit future bookings */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg">
                            <div className="flex-1">
                              <div className="text-gray-900 mb-1">Limit future bookings</div>
                              <div className="text-gray-500 text-sm">Limit how far in the future this event can be booked</div>
                            </div>
                            <Switch
                              checked={limitFutureBookings}
                              onCheckedChange={setLimitFutureBookings}
                            />
                          </div>
                        </div>
                      </>
                    ) : selectedEventSection === "availability" ? (
                      <>
                        {/* Availability Schedule Selector */}
                        <div className="space-y-4">
                          <Label>Availability</Label>
                          <Select value={selectedAvailability} onValueChange={setSelectedAvailability}>
                            <SelectTrigger className="w-full">
                              <div className="flex items-center gap-2">
                                <SelectValue />
                                <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded">
                                  Default
                                </span>
                              </div>
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Working Hours">Working Hours</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Weekly Schedule */}
                        <div className="space-y-3">
                          {weeklySchedule.map((schedule) => (
                            <div key={schedule.day} className="grid grid-cols-[120px_1fr_auto_1fr] gap-3 items-center">
                              <div className="text-gray-900">{schedule.day}</div>
                              {schedule.available ? (
                                <>
                                  <Input 
                                    value={schedule.start} 
                                    readOnly
                                    className="text-center"
                                  />
                                  <span className="text-gray-500">-</span>
                                  <Input 
                                    value={schedule.end} 
                                    readOnly
                                    className="text-center"
                                  />
                                </>
                              ) : (
                                <div className="col-span-3 text-gray-500">Unavailable</div>
                              )}
                            </div>
                          ))}
                        </div>

                        {/* Timezone */}
                        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Globe className="h-4 w-4" />
                            <span>America/New_York</span>
                          </div>
                          <Button variant="link" className="text-gray-600 p-0 h-auto">
                            Edit availability
                          </Button>
                        </div>
                      </>
                    ) : (
                      <div className="text-center text-gray-500 py-12">
                        This section is not yet implemented
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : currentView === "availability" ? (
          <>
            {isEditingAvailability ? (
              <>
                {/* Edit/New Availability Header */}
                <div className="border-b border-gray-200 p-6">
                  <button 
                    onClick={() => setIsEditingAvailability(false)}
                    className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Back</span>
                  </button>
                  <h1 className="text-gray-900 mb-1">
                    {availabilityName ? "Edit Schedule" : "New Schedule"}
                  </h1>
                  <p className="text-gray-600">
                    Configure your availability schedule
                  </p>
                </div>

                {/* Edit/New Availability Content */}
                <div className="flex-1 p-6 overflow-y-auto">
                  <div className="max-w-3xl space-y-6">
                    {/* Schedule Name */}
                    <div className="space-y-2">
                      <Label htmlFor="schedule-name">Schedule Name</Label>
                      <Input
                        id="schedule-name"
                        placeholder="Working Hours"
                        value={availabilityName}
                        onChange={(e) => setAvailabilityName(e.target.value)}
                      />
                    </div>

                    {/* Timezone */}
                    <div className="space-y-2">
                      <Label htmlFor="timezone">Timezone</Label>
                      <Select value={availabilityTimezone} onValueChange={setAvailabilityTimezone}>
                        <SelectTrigger id="timezone">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="america-new-york">
                            (GMT-05:00) America/New York
                          </SelectItem>
                          <SelectItem value="america-los-angeles">
                            (GMT-08:00) America/Los Angeles
                          </SelectItem>
                          <SelectItem value="america-chicago">
                            (GMT-06:00) America/Chicago
                          </SelectItem>
                          <SelectItem value="europe-london">
                            (GMT+00:00) Europe/London
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Weekly Schedule */}
                    <div className="space-y-4">
                      <Label>Weekly Hours</Label>
                      <div className="space-y-3">
                        {weeklySchedule.map((schedule) => (
                          <div key={schedule.day} className="flex items-center gap-4">
                            <div className="w-28">
                              <Checkbox id={`day-${schedule.day}`} defaultChecked={schedule.available} />
                              <label htmlFor={`day-${schedule.day}`} className="ml-2 text-gray-900">
                                {schedule.day}
                              </label>
                            </div>
                            {schedule.available && (
                              <div className="flex items-center gap-2 flex-1">
                                <Input 
                                  type="time" 
                                  defaultValue="12:00"
                                  className="w-32"
                                />
                                <span className="text-gray-500">to</span>
                                <Input 
                                  type="time" 
                                  defaultValue="16:00"
                                  className="w-32"
                                />
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Save Buttons */}
                    <div className="flex justify-end gap-3 pt-4">
                      <Button 
                        variant="outline"
                        onClick={() => setIsEditingAvailability(false)}
                      >
                        Cancel
                      </Button>
                      <Button onClick={() => setIsEditingAvailability(false)}>
                        Save
                      </Button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Availability Header */}
                <div className="border-b border-gray-200 p-6 flex items-start justify-between">
                  <div>
                    <h1 className="text-gray-900 mb-1">Availability</h1>
                    <p className="text-gray-600">
                      Configure times when you are available for bookings.
                    </p>
                  </div>
                  <Button 
                    className="gap-2"
                    onClick={() => {
                      setAvailabilityName("");
                      setIsEditingAvailability(true);
                    }}
                  >
                    <Plus className="h-4 w-4" />
                    New
                  </Button>
                </div>

                {/* Availability Content */}
                <div className="flex-1 p-6 overflow-y-auto">
              {/* Working Hours Card */}
              <div className="border border-gray-200 rounded-lg p-4 mb-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-gray-900">Working Hours</h3>
                      <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
                        Default
                      </span>
                    </div>
                    <p className="text-gray-900 mb-1">Mon - Fri, 12:00 PM - 4:00 PM</p>
                    <div className="flex items-center gap-1 text-gray-600">
                      <Globe className="h-4 w-4" />
                      <span>America/New_York</span>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="p-2 hover:bg-gray-100 rounded">
                        <MoreHorizontal className="h-4 w-4 text-gray-600" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem 
                        onClick={() => {
                          setAvailabilityName("Working Hours");
                          setIsEditingAvailability(true);
                        }}
                      >
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem>Duplicate</DropdownMenuItem>
                      <DropdownMenuItem>Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>
              </>
            )}
          </>
        ) : currentView === "auth-screens" ? (
          <AuthScreensDemo />
        ) : (
          <>
            {/* Bookings Header */}
            <div className="border-b border-gray-200 p-6">
              <h1 className="text-gray-900 mb-1">Bookings</h1>
              <p className="text-gray-600">
                See upcoming and past events booked through your event type links.
              </p>
            </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 px-6">
          <div className="flex gap-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-3 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-gray-900 text-gray-900"
                    : "border-transparent text-gray-600 hover:text-gray-900"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Filter Bar */}
        <div className="p-6 pb-4 flex items-center justify-between">
          <Button variant="outline" className="gap-2" onClick={() => setIsFilterOpen(true)}>
            <SlidersHorizontal className="h-4 w-4" />
            Filter
          </Button>
          <div className="flex items-center gap-3">
            <Button variant="ghost" className="gap-2 text-gray-600">
              <Bookmark className="h-4 w-4" />
              Save
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 text-gray-600">
                  Saved filters
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Filter 1</DropdownMenuItem>
                <DropdownMenuItem>Filter 2</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Bookings List */}
        <div className="flex-1 px-6 pb-6 overflow-y-auto">
          <div className="space-y-3">
            {bookings.map((booking) => (
              <div 
                key={booking.id}
                className="flex items-start justify-between p-4 border border-gray-200 rounded-lg hover:border-gray-300 cursor-pointer"
                onClick={() => setSelectedBooking(booking.id)}
              >
                <div className="flex gap-4 flex-1">
                  <div className="text-gray-600 min-w-[140px]">
                    <div>{booking.date}</div>
                    <div>{booking.time}</div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-gray-900 mb-1">{booking.title}</h3>
                    <p className="text-gray-600 mb-2">{booking.attendees}</p>
                    {booking.hasGoogleMeet && (
                      <button 
                        className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Video className="h-4 w-4" />
                        Join Google Meet
                      </button>
                    )}
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button 
                      className="p-2 hover:bg-gray-100 rounded"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <MoreHorizontal className="h-4 w-4 text-gray-600" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setSelectedBooking(booking.id)}>View details</DropdownMenuItem>
                    <DropdownMenuItem>Reschedule</DropdownMenuItem>
                    <DropdownMenuItem>Cancel</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ))}
          </div>
        </div>

            {/* Pagination */}
            <div className="border-t border-gray-200 px-6 py-4 flex items-center justify-between">
              <Select defaultValue="10">
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10 rows per page</SelectItem>
                  <SelectItem value="25">25 rows per page</SelectItem>
                  <SelectItem value="50">50 rows per page</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center gap-4">
                <span className="text-gray-600">1-1 of 1</span>
                <div className="flex gap-1">
                  <Button variant="outline" size="sm" disabled>
                    &lt;
                  </Button>
                  <Button variant="outline" size="sm" disabled>
                    &gt;
                  </Button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* New Event Dialog */}
      <Dialog open={isNewEventDialogOpen} onOpenChange={setIsNewEventDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add a new event type</DialogTitle>
            <DialogDescription>
              Set up event types to offer different types of meetings.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                placeholder="Quick Chat"
                value={newEventTitle}
                onChange={(e) => setNewEventTitle(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="url">URL</Label>
              <Input
                id="url"
                placeholder="https://yourdomain.com/username/"
                value={newEventUrl}
                onChange={(e) => setNewEventUrl(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <div className="border border-gray-200 rounded-md">
                <div className="flex items-center gap-1 p-2 border-b border-gray-200">
                  <button className="p-1 hover:bg-gray-100 rounded">
                    <Bold className="h-4 w-4 text-gray-600" />
                  </button>
                  <button className="p-1 hover:bg-gray-100 rounded">
                    <Italic className="h-4 w-4 text-gray-600" />
                  </button>
                </div>
                <Textarea
                  id="description"
                  placeholder="A quick video meeting."
                  value={newEventDescription}
                  onChange={(e) => setNewEventDescription(e.target.value)}
                  className="border-0 focus-visible:ring-0 resize-none"
                  rows={3}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Duration</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="duration"
                  type="number"
                  value={newEventDuration}
                  onChange={(e) => setNewEventDuration(e.target.value)}
                  className="w-24"
                />
                <span className="text-gray-600">minutes</span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNewEventDialogOpen(false)}>
              Close
            </Button>
            <Button onClick={() => setIsNewEventDialogOpen(false)}>
              Continue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Filter Sheet */}
      <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
        <SheetContent className="w-[400px] sm:w-[540px] flex flex-col">
          <SheetHeader>
            <SheetTitle>Filters</SheetTitle>
            <SheetDescription>
              Filter bookings by event type, date, and more
            </SheetDescription>
          </SheetHeader>
          
          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
            {/* Event Type Filter */}
            <div className="space-y-3">
              <Label className="text-gray-900">Event Type</Label>
              <div className="space-y-3">
                {["30 Minute Meeting", "Discovery Call", "Quick Sync", "Strategy Session"].map((type) => (
                  <div key={type} className="flex items-center space-x-3">
                    <Checkbox
                      id={`event-${type}`}
                      checked={filterEventTypes.includes(type)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setFilterEventTypes([...filterEventTypes, type]);
                        } else {
                          setFilterEventTypes(filterEventTypes.filter(t => t !== type));
                        }
                      }}
                    />
                    <label
                      htmlFor={`event-${type}`}
                      className="text-sm text-gray-700 cursor-pointer flex-1"
                    >
                      {type}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Date Range Filter */}
            <div className="space-y-3">
              <Label className="text-gray-900">Date Range</Label>
              <Select value={filterDateRange} onValueChange={setFilterDateRange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="this-week">This week</SelectItem>
                  <SelectItem value="this-month">This month</SelectItem>
                  <SelectItem value="next-7-days">Next 7 days</SelectItem>
                  <SelectItem value="next-30-days">Next 30 days</SelectItem>
                  <SelectItem value="custom">Custom range</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Meeting Type Filter */}
            <div className="space-y-3">
              <Label className="text-gray-900">Meeting Type</Label>
              <div className="space-y-3">
                {[
                  { id: "google-meet", label: "Google Meet" },
                  { id: "zoom", label: "Zoom" },
                  { id: "phone", label: "Phone call" },
                  { id: "in-person", label: "In-person" },
                  { id: "no-location", label: "No location" }
                ].map((type) => (
                  <div key={type.id} className="flex items-center space-x-3">
                    <Checkbox
                      id={`meeting-${type.id}`}
                      checked={filterMeetingTypes.includes(type.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setFilterMeetingTypes([...filterMeetingTypes, type.id]);
                        } else {
                          setFilterMeetingTypes(filterMeetingTypes.filter(t => t !== type.id));
                        }
                      }}
                    />
                    <label
                      htmlFor={`meeting-${type.id}`}
                      className="text-sm text-gray-700 cursor-pointer flex-1"
                    >
                      {type.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Duration Filter */}
            <div className="space-y-3">
              <Label className="text-gray-900">Duration</Label>
              <div className="space-y-3">
                {[
                  { id: "15", label: "15 minutes" },
                  { id: "30", label: "30 minutes" },
                  { id: "60", label: "1 hour" },
                  { id: "90", label: "1.5 hours" },
                  { id: "120", label: "2 hours" }
                ].map((duration) => (
                  <div key={duration.id} className="flex items-center space-x-3">
                    <Checkbox
                      id={`duration-${duration.id}`}
                      checked={filterDurations.includes(duration.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setFilterDurations([...filterDurations, duration.id]);
                        } else {
                          setFilterDurations(filterDurations.filter(d => d !== duration.id));
                        }
                      }}
                    />
                    <label
                      htmlFor={`duration-${duration.id}`}
                      className="text-sm text-gray-700 cursor-pointer flex-1"
                    >
                      {duration.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="border-t border-gray-200 bg-white px-6 py-4 flex items-center justify-between mt-auto">
            <Button
              variant="ghost"
              onClick={() => {
                setFilterEventTypes([]);
                setFilterDateRange("all");
                setFilterMeetingTypes([]);
                setFilterDurations([]);
              }}
            >
              Clear all
            </Button>
            <Button onClick={() => setIsFilterOpen(false)}>
              Apply filters
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
