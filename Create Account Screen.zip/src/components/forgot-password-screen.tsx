import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { ArrowLeft, Mail, Check } from "lucide-react";

interface ForgotPasswordScreenProps {
  onBackToLogin?: () => void;
}

export function ForgotPasswordScreen({ onBackToLogin }: ForgotPasswordScreenProps) {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock email sending
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="w-full max-w-[420px]">
          {/* Logo/Brand Area */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-green-100 mb-4">
              <Check className="w-6 h-6 text-green-600" />
            </div>
            <h1 className="text-gray-900 mb-2">
              Check your email
            </h1>
            <p className="text-gray-600">
              If an account exists for {email}, you will receive password reset instructions.
            </p>
          </div>

          {/* Card */}
          <div className="bg-white border border-gray-200 rounded-lg p-8">
            <div className="space-y-4">
              <p className="text-gray-600">
                We've sent a password reset link to your email address. Please check your inbox and spam folder.
              </p>
              <p className="text-gray-600">
                The link will expire in 1 hour.
              </p>
            </div>
          </div>

          {/* Back to login */}
          <div className="text-center mt-6">
            <button
              onClick={onBackToLogin}
              className="inline-flex items-center gap-2 text-gray-900 hover:underline"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to sign in
            </button>
          </div>

          {/* Resend */}
          <div className="text-center mt-4">
            <p className="text-gray-500">
              Didn't receive the email?{" "}
              <button
                onClick={() => setIsSubmitted(false)}
                className="text-gray-900 hover:underline"
              >
                Try again
              </button>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-[420px]">
        {/* Logo/Brand Area */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-gray-900 mb-4">
            <Mail className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-gray-900 mb-2">
            Forgot your password?
          </h1>
          <p className="text-gray-600">
            Enter your email address and we'll send you a link to reset your password.
          </p>
        </div>

        {/* Reset form */}
        <div className="bg-white border border-gray-200 rounded-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email field */}
            <div className="space-y-2">
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                type="email"
                placeholder="john.doe@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full"
              />
            </div>

            {/* Submit button */}
            <Button type="submit" className="w-full bg-gray-900 hover:bg-gray-800 text-white">
              Send reset link
            </Button>
          </form>
        </div>

        {/* Back to login */}
        <div className="text-center mt-6">
          <button
            onClick={onBackToLogin}
            className="inline-flex items-center gap-2 text-gray-900 hover:underline"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to sign in
          </button>
        </div>
      </div>
    </div>
  );
}
