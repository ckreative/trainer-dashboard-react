import { useState } from "react";
import { LoginScreen } from "./login-screen";
import { ForgotPasswordScreen } from "./forgot-password-screen";
import { ResetPasswordScreen } from "./reset-password-screen";

type AuthView = "login" | "forgot-password" | "reset-password";

export function AuthScreensDemo() {
  const [authView, setAuthView] = useState<AuthView>("login");

  const handleLogin = (email: string, password: string) => {
    console.log("Login attempted with:", email, password);
    // Handle login logic here
  };

  const handlePasswordReset = () => {
    console.log("Password reset successful");
    setAuthView("login");
  };

  return (
    <>
      {authView === "login" && (
        <LoginScreen
          onForgotPassword={() => setAuthView("forgot-password")}
          onSignUp={() => console.log("Navigate to signup")}
          onLogin={handleLogin}
        />
      )}
      {authView === "forgot-password" && (
        <ForgotPasswordScreen
          onBackToLogin={() => setAuthView("login")}
        />
      )}
      {authView === "reset-password" && (
        <ResetPasswordScreen
          onPasswordReset={handlePasswordReset}
          onBackToLogin={() => setAuthView("login")}
        />
      )}
    </>
  );
}
